<?php $titulo="Preguntas"; ?>
<?php include('../assets/InicioDocumento.php'); ?>
	<label>Categor&iacute;a 1: General</label>
	<br><br>
	<table>
		<tr>
			<th>C&oacute;digo</th>
			<th>Descripci&oacute;n</th>
			<th>Tipo</th>
			<th colspan="2">Acciones</th>
		</tr>
		<tr>
			<td>1</td>
			<td>Pregunta 1</td>
			<td>Abierta</td>
			<td><a href="ModificarPregunta.php"><img src="images/editar.png" border="0" height=20 /></a></td>
			<td><a href="EliminarPregunta.php"><img src="images/eliminar.png" border="0" height=20 /></a></td>
		</tr>
		<tr>
			<td>2</td>
			<td>Pregunta 2</td>
			<td>Verdadero/Falso</td>
			<td><a href="ModificarPregunta.php"><img src="images/editar.png" border="0" height=20 /></a></td>
			<td><a href="EliminarPregunta.php"><img src="images/eliminar.png" border="0" height=20 /></a></td>
		</tr>
	</table>
	<label>Categor&iacute;a 2: Ambiente</label>
	<br><br>
	<table>
		<tr>
			<th>C&oacute;digo</th>
			<th>Descripci&oacute;n</th>
			<th>Tipo</th>
			<th colspan="2">Acciones</th>
		</tr>
		<tr>
			<td>3</td>
			<td>Pregunta 3</td>
			<td>Abierta</td>
			<td><a href="ModificarPregunta.php"><img src="images/editar.png" border="0" height=20 /></a></td>
			<td><a href="EliminarPregunta.php"><img src="images/eliminar.png" border="0" height=20 /></a></td>
		</tr>
		<tr>
			<td>4</td>
			<td>Pregunta 4</td>
			<td>Verdadero/Falso</td>
			<td><a href="ModificarPregunta.php"><img src="images/editar.png" border="0" height=20 /></a></td>
			<td><a href="EliminarPregunta.php"><img src="images/eliminar.png" border="0" height=20 /></a></td>
		</tr>
	</table> 
<?php include('../assets/FinDocumento.php'); ?>