<!-- sidebar -->
<aside class="col-md-3 col-xs-12 no_left">
    <!-- Menu -->
    <nav id="nav">
        <?php
            switch($_SESSION["tipoUsario"])
            {
                case "admin":
                    include('menuBase.php');
                    break;
                case "entrevistador":
                    include('menuEntrevistador.php');
                    break;
            }
        ?>
    </nav>
    <!-- Fin del menu -->

    <div class="bloc ">
        <h3 class="verde">ANUNCIOS</h3>
        <span class="date green">05/09/2016</span>
        <p class="grey">Las encuestas porporcionadas tienen por objetivo conocer...</p>
    </div>

</aside>
<!-- end sidebar -->