<!-- footer -->
<footer class="footer">
    <div class="container">
        <div class="row">

            <div class="col-md-8 col-xs-12 align_right">
                <p class="copyright">Copyright &#169; 2016  Todos los derechos reservados</p>
            </div>
        </div>
    <div class="menupie">
    <ul>
        <li><a href="">Inicio</a></li>
        <li><a href="">Nosotros</a></li>
        <li><a href="">Servicios</a></li>
        <li><a href="">Contacto</a></li>
    </ul>
    </div>
    <div class="logos">
        <img src="../assets/img/logos/prodep.png" border="0" height=40 />
        <img src="../assets/img/logos/UTyP.png" border="0" height=40 />
        <img src="../assets/img/logos/UTJ.png" border="0" height=50 />
        <img src="../assets/img/logos/UTTT.png" border="0" height=50 />
        <img src="../assets/img/logos/UTBB.png" border="0" height=50 />
    </div>
    </div>
</footer>
<!-- end footer -->