<ul id="menu">
    <li class="active">
        <a href="">
            <i class="icon-arrow"></i>
            <span>INICIO</span>
            <div class="bg-nav"></div>
        </a>
    </li>
    <li>
        <a href="#" class="sub" tabindex="1">
        <i class="icon-arrow"></i>
        <span>ENCUESTAS</span>
        <div class="bg-nav"></div>
        </a><img src="" alt="" />
        <ul>
            <li><a href="#">Crear nueva</a></li>
            <li><a href="#">Buscar</a></li>
            <li><a href="#">Modificar</a></li>
            <li><a href="#">Eliminar</a></li>
            <li><a href="#">Contestar</a></li>
        </ul>
    </li>
    <li>
        <a href="#" class="sub" tabindex="1">
        <i class="icon-arrow"></i>
        <span>USUARIOS Y PERFILES</span>
        <div class="bg-nav"></div>
        </a><img src="" alt="" />
        <ul>
            <li><a href="#">Nuevo usuario</a></li>
            <li><a href="#">Buscar usuario</a></li>
            <li><a href="#">Modificar datos de usuario</a></li>
            <li><a href="#">Eliminar usuario</a></li>
            <li><a href="#">Crear perfil de usuario</a></li>
            <li><a href="#">Mostrar perfiles</a></li>
            <li><a href="#">Modificar perfil</a></li>
            <li><a href="#">Eliminar perfil</a></li>
        </ul>
    </li>
    <li>
        <a href="#" class="sub" tabindex="1">
        <i class="icon-arrow"></i>
        <span>PREGUNTAS Y CATEGOR&Iacute;AS</span>
        <div class="bg-nav"></div>
        </a><img src="" alt="" />
        <ul>
            <li><a href="#">Crear categor&iacute;a</a></li>
            <li><a href="#">Buscar categor&iacute;a</a></li>
            <li><a href="#">Modificar categor&iacute;a</a></li>
            <li><a href="#">Eliminar categor&iacute;a</a></li>
            <li><a href="#">Crear pregunta</a></li>
            <li><a href="#">Buscar pregunta</a></li>
            <li><a href="#">Modificar pregunta</a></li>
            <li><a href="#">Eliminar pregunta</a></li>
        </ul>
    </li>
    <li>
        <a href="#" class="sub" tabindex="1">
        <i class="icon-arrow"></i>
        <span>ENCUESTADORES</span>
        <div class="bg-nav"></div>
        </a><img src="" alt="" />
        <ul>
            <li><a href="#">Dar de alta nuevo</a></li>
            <li><a href="#">Buscar</a></li>
            <li><a href="#">Modificar</a></li>
            <li><a href="#">Eliminar</a></li>
            <li><a href="#">Encuestadores asociados</a></li>
        </ul>
    </li>
    <li>
        <a href="#" class="sub" tabindex="1">
        <i class="icon-arrow"></i>
        <span>UTILER&Iacute;AS</span>
        <div class="bg-nav"></div>
        </a><img src="" alt="" />
        <ul>
            <li><a href="#">Descargar formatos</a></li>
            <li><a href="#">Realizar respaldo</a></li>
            <li><a href="#">Recuperar respaldo</a></li>
        </ul>
    </li>
</ul>