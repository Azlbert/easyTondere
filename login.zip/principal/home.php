<?php $titulo="Contenido"; ?>
<?php include("../assets/InicioDocumento.php"); ?>
    <p>En esta parte deben poner el contenido que les toca!!!!</p>
    <p>Una encuesta es un procedimiento dentro de los diseños de una investigación descriptiva en el que el investigador 
    busca recopilar datos por medio de un cuestionario previamente diseñado, sin modificar el entorno ni el fenómeno donde 
    se recoge la información ya sea para entregarlo en forma de tríptico, gráfica o tabla. Los datos se obtienen realizando 
    un conjunto de preguntas normalizadas dirigidas a una muestra representativa o al conjunto total de la población 
    estadística en estudio, integrada a menudo por personas, empresas o antes institucionales, con el fin de conocer 
    estados de opinión, ideas, características o hechos específicos.</p>
    <p>Existen en el mercado un sinnúmero de herramientas de software profesionales para realizar el procesamiento de 
    la encuesta de forma eficiente y productiva. El tipo de software a utilizar dependerá en gran medida de la metodología 
    de aplicación del instrumento en campo, es decir, si la encuesta será autoadministrada o administrada mediante entrevista 
    personal; igualmente, el tipo de software dependerá del medio de captura, bien sea papel (PAPI), web (CAWI), entrevista 
    telefónica (CATI) o dispositivos móviles (CAPI). Algunas herramientas para el escritorio o para la web ofrecen una 
    facilidad llamada OLAP, lo cual permite almacenar los datos en un formato cúbico y así poder rotar las dimensiones 
    de análisis para obtener múltiples vistas de la información y poder analizar fácilmente cada pregunta del cuestionario 
    por sus variables de análisis (sexo, ciudad, edad, estrato social, etcétera).
    </p>
    <p>La encuesta es una técnica de recogida de datos mediante la aplicación de un cuestionario a una muestra de individuos.
    A través de las encuestas se pueden conocer las opiniones, las actitudes y los comportamientos de los ciudadanos. 
    Las encuestas tienen su origen en los Estados Unidos en las investigaciones de mercados  en los sondeos de opinión ante 
    las elecciones de la Casa Blanca. Hasta nuestros oídos nos llegan nombres como Gallup o Crossley que supieron transferir
    su experiencia en los estudios de mercado al campo de las elecciones electorales. Consiguieron con muestras reducidas de 
    la población americana realizar una previsión acertada d la elección del presidente Roosevenlt. 
    En   España el CIS ( Centro de Investigaciones Sociológicas) dependiente de la presidencia del gobierno y continuador 		
    del desaparecido Instituto de la Opinión Publica –Organismo inicialmente adscrito al Ministerio de Información y Turismo, 
    paso en 1976 a depender de la Presidencia del Gobierno- es el organismo encarado de realizar los sondeos de Opinión de la 
    mayoría de los españoles. Loa temas de estudio son de lo mas variado, desde temas de educación , región,, población, 
    familia, medio ambiente, etc., hasta mercado de trabajo, sindicatos, ocio, delincuencia, etc., no olvidando los referidos 
    a la política con encuestas sobre elecciones, actitudes políticas, comportamientos político, etc. En una encuesta se 
    realizan una serie de preguntas sobre uno o varios temas a una muestra de personas seleccionadas siguiendo una serie 
    de reglas científicas que hacen que esa muestra sea, en su conjunto, representativa de la población general de la que 
    procede.</p>
<?php include("../assets/FinDocumento.php"); ?>