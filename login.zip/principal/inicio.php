<?php $titulo="Inicio"; ?>
<?php include('../assets/InicioDocumento.php'); ?>					
    <h2>MI PERFIL</h2>
    <div>
        <div class="row">
        <div class="col-md-4 col-xs-12">
        <img src="../files/profile/foto.png" width="150" >
        </div>
        <p><b>Razón social:</b> EMPRESAMEX</p>
        <p><b>Domicilio:</b> Av.Vallarta 5148</p>
        <p><b>Télefono:</b> 3333164582</p>
        <p><b>Correo electrónico:</b> miempresa@gmail.com</p>
        <div class="col-md-12">
        <div class="botones">
        <a href="#" class="boton">Editar perfil</a>
        <a href="#" class="boton">Cambiar contraseña</a>
        <a href="#" class="boton">Cerrar sesión</a>
        </div>
        <div class="progreso">
        <a href="#"> Encuesta 01 </a><br><br>
        <progress value="70" max="100">70%</progress>
        <b>70%</b>
        <br><br><br><br>
        <br><br><br><br>
        </div>
        </div>
        </div>
    </div>
<?php include("../assets/FinDocumento.php"); ?>