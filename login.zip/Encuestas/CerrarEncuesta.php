<?php $titulo="Cerrar Encuesta"; ?>
<?php include('../assets/InicioDocumento.php'); ?>
	<form id="formulario" action="" method="post" >
		<label>Nombre</label>
		<input id="nombre" name="nombre" type="text" placeholder='Nombre' value='Encuesta'/>
		<br>    
		<input id="Cerrar" name="Cerrar" type="submit" value="Cerrar" />
	</form>
<?php include('../assets/FinDocumento.php'); ?>