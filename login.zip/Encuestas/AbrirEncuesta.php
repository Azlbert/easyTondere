<?php $titulo="Abrir Encuesta"; ?>
<?php include('../assets/InicioDocumento.php'); ?>
	<form id="formulario" action="" method="post" >
		<label>Nombre</label>
		<input id="nombre" name="nombre" type="text" placeholder='Nombre' value='Encuesta'/>
		<br>    
		<input id="Abrir" name="Abrir" type="submit" value="Abrir" />
	</form>
<?php include('../assets/FinDocumento.php'); ?>