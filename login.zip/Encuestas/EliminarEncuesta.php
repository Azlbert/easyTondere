<?php $titulo="Eliminar Encuesta"; ?>
<?php include('../assets/InicioDocumento.php'); ?>
	<form id="formulario" action="" method="post" >
		<label>Nombre</label>
		<input id="nombre" name="nombre" type="text" placeholder='Nombre' value='Encuesta'/>
		<br>    
		<input id="Eliminar" name="Eliminar" type="submit" value="Modificar" />
	</form>
<?php include('../assets/FinDocumento.php'); ?>